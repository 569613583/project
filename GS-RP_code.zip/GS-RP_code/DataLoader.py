import os
import json
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision.transforms import transforms
from PIL import Image
import numpy as np


class celebaDataset(Dataset):
    def __init__(self, img_pth, size, label_flag=False):
        self.img_pth = img_pth  # 文件路径
        self.size = size  # 图片大小
        self.img_list = []  # 图片列表
        for dirpath, _, filenames in os.walk(img_pth):  # os.walk 递归遍历
            for file_name in filenames:
                # 检查是否为图像文件
                if file_name.endswith(('.png', '.jpg', '.jpeg', '.bmp', 'JPEG', 'PNG')):
                    self.img_list.append(os.path.join(dirpath, file_name))
        # self.transform = clip.load("D:\yangmeng\PHD UTS\liuchiexpirement\clipencoder\clip\ViT-B-32.pt")[1]
        self.transform = transforms.Compose(
            [
                # transforms.RandomResizedCrop(self.size),
                transforms.Resize((self.size, self.size)),
                transforms.ToTensor(),
                #transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225)),
                transforms.Normalize([0.5], [0.5])
            ]
        )
        self.label_flag = label_flag
        # self.img_list = sorted(self.img_list)

    def __len__(self):
        return len(self.img_list)  # 返回图片数量

    def __getitem__(self, idx):
        img_name = self.img_list[idx]
        try:
            img = Image.open(os.path.join(img_name))  # 加载图像
            img = img.convert('RGB')  # 确保图像是RGB格式
        except Exception as e:
        # 记录损坏文件的路径
            print(f"!!! 损坏文件: {img_name} !!!")
        img = self.transform(img)
        if self.label_flag:
            return img, torch.tensor([1.0])
        else:
            return img


class PTDataset(Dataset):
    def __init__(self, pt_path):
        """
        读取 .pt 文件，假设文件内容是一个形状为 [N, C, H, W] 的 Tensor
        """
        super().__init__()
        # map_location='cpu' 避免直接占用显存，读取时放在内存中
        self.data = torch.load(pt_path, map_location='cpu')
        
        # 简单检查数据格式
        if isinstance(self.data, list):
            self.data = torch.stack(self.data)
            
    def __getitem__(self, index):
        # 返回单个样本
        return self.data[index]

    def __len__(self):
        return len(self.data)

if __name__ == '__main__':
    from torchvision.utils import save_image
    from torch.autograd import Variable
    img_pth = "./dataset/celeba_test"
    dataset = celebaDataset(img_pth, size=224, label_flag=True)  # 打上标签
    dataloader = DataLoader(dataset, batch_size=32, shuffle=True)  # shuffle=True表示每个epoch打乱数据
    for i, img in enumerate(dataloader):
        Tensor = torch.cuda.FloatTensor
        img = img[0]
        img = Variable(img.type(Tensor))
        noise_strength = 0.15
        noise = torch.randn_like(img) * noise_strength
        img = torch.clamp(img + noise, 0, 1)
        save_image(img, "images/1.jpg", nrow=8, normalize=False)