import matplotlib.pyplot as plt
import numpy as np
from sklearn.manifold  import TSNE
import torch
from sklearn.decomposition import PCA

class Distribution:
    def __init__(self, imagenet, progan, sd, stylegan, stylegan3, count, is_fake=False):
        self.imagenet = imagenet
        self.progan = progan
        self.sd = sd
        self.stylegan = stylegan
        self.stylegan3 = stylegan3
        self.is_fake = is_fake
        self.count = count

    def visualize_feature_distributions(self):
        with torch.no_grad():
            # 转换为numpy数组
            if self.is_fake:
                feature_vectors = [
                    self.imagenet,
                    self.progan, 
                    self.sd, 
                    self.stylegan, 
                    self.stylegan3, 
                ]

            # 使用t-SNE降维到2维
            all_features = np.vstack(feature_vectors)
            n_samples = all_features.shape[0]
            perplexity = min(29, max(5, n_samples // 3))  # 动态调整
            tsne = TSNE(n_components=2, 
                        perplexity=perplexity, 
                        early_exaggeration=8,
                        )
            reduced_features = all_features.reshape(n_samples, -1)
            reduced_features = tsne.fit_transform(reduced_features)

        plt.figure(figsize=(5, 4))

        if self.is_fake:
            colors = ['#6EC4A9', '#ED949A', '#96CCEA', '#F28E33', '#B2A3DD']
            labels = ['ImageNet-1k', 'ProGAN', 'SD 1.4', 'StyleGAN', 'StyleGAN3']

        start_idx = 0
        for i in range(len(feature_vectors)):
            end_idx = start_idx + len(feature_vectors[i])
            plt.scatter(reduced_features[start_idx:end_idx, 0], 
                        reduced_features[start_idx:end_idx, 1], 
                        c=colors[i],
                        s=6,  # 减小点大小
                        alpha=0.8,  # 增加透明度提升亮度
                        label=labels[i])
            start_idx = end_idx

        plt.title("Feature  Distribution")
        plt.xlabel('t-SNE  Dimension 1')
        plt.ylabel('t-SNE  Dimension 2')
        legend = plt.legend(
            loc='upper right',
            borderpad=0.3,
            bbox_to_anchor=(0.98, 0.98),  # 相对于 axes 的坐标 (1,1) 是右上角，0.98,0.98 稍内缩
            fontsize=9,
            frameon=True
        )
        # 半透明背景（更好融入图中）
        legend.get_frame().set_alpha(0.6)
        legend.get_frame().set_linewidth(0.3)
        # 刷新图表
        plt.draw()
        plt.tight_layout()
        if self.is_fake:
            plt.savefig(f'visual_picture/fake_loss_plot_distribution_{self.count}.png')
        else:
            plt.savefig(f'visual_picture/real_loss_plot_distribution_{self.count}.png')

class Visual:
    def __init__(self, losses):
        self.losses = losses

    def plot_loss(self):
        losses = self.losses

        fig, ax = plt.subplots()

        # 初始化图表
        x = np.arange(len(losses))
        y = losses
        line, = ax.plot(x, y, label='Loss', color='orange')
        ax.set_xlabel('Iteration')
        ax.set_ylabel('Loss')
        ax.legend()

        # 刷新图表
        plt.draw()

        # 保存图形到文件
        plt.savefig('loss_plot.png')

class Distribution_1:
    def __init__(self, img_embeds1, img_embeds2, img_embeds3, img_embeds4, img_embeds5, fake):
        self.img_embeds1 = img_embeds1
        self.img_embeds2 = img_embeds2
        self.img_embeds3 = img_embeds3
        self.img_embeds4 = img_embeds4
        self.img_embeds5 = img_embeds5
        self.fake = fake

    def visualize_feature_distributions(self):
        with torch.no_grad():
            # 转换为numpy数组
            # real_img_embeds = torch.mean(self.real_img_embeds, dim=1).reshape(-1, 1, 224, 224)
            # fake_img_embeds = torch.mean(self.fake_img_embeds, dim=1).reshape(-1, 1, 224, 224)
            feature_vectors = [
                self.img_embeds1,
                self.img_embeds2,
                self.img_embeds3,
                self.img_embeds4,
                self.img_embeds5,
                self.fake,
            ]

            # 使用t-SNE降维到2维
            all_features = np.vstack(feature_vectors)
            n_samples = all_features.shape[0]
            perplexity = min(8, 10000)  # 动态调整
            pca = PCA(n_components=2)
            tsne = TSNE(n_components=2, 
                        perplexity=perplexity, 
                        early_exaggeration=12,
                        random_state=42)
            reduced_features = all_features.reshape(n_samples, -1)
            reduced_features = tsne.fit_transform(reduced_features)

        plt.figure(figsize=(6, 5))

        colors = ['#6EC4A9', '#ED949A', '#96CCEA', '#F28E33', '#B2A3DD', "#7C7E7F"]  # 扩展颜色列表以匹配元素数量
        labels = ['Real-Embedding1', 'Real-Embedding2', 'Real-Embedding3', 'Real-Embedding4', 'Real-Embedding5', 'Fake-Image']
        colors1 = ["#282A62", "#282A62", "#282A62", "#282A62", "#282A62", "#872B2B"]

        start_idx = 0
        for i in range(len(feature_vectors)):
            end_idx = start_idx + len(feature_vectors[i])
            plt.scatter(reduced_features[start_idx:end_idx, 0],
                        reduced_features[start_idx:end_idx, 1],
                        c=colors[i],
                        s=6,  # 减小点大小
                        alpha=0.8,  # 增加透明度提升亮度
                        label=labels[i])
            start_idx = end_idx

        plt.title("Feature  Distribution of Four Encoders")
        plt.xlabel('t-SNE  Dimension 1')
        plt.ylabel('t-SNE  Dimension 2')
        # plt.legend(
        #     loc='upper left',
        #     bbox_to_anchor=(1.02, 1),
        #     borderpad=0.3,  # 默认值为0.4，数值越小边框越紧凑
        #     labelspacing=0.3,
        #     handlelength=1.0,
        #     fontsize=6,
        #     frameon=True  # 确保边框显示
        # )
        # 把图例放在图内部右上角，带半透明背景
        legend = plt.legend(
            loc='upper right',
            borderpad=0.2,
            bbox_to_anchor=(1, 1),  # 相对于 axes 的坐标 (1,1) 是右上角，0.98,0.98 稍内缩
            fontsize=4,
            markerscale=3,
            frameon=True,
            prop={'weight': 'bold'}
        )
        # 半透明背景（更好融入图中）
        # legend.get_frame().set_alpha(0.6)
        legend.get_frame().set_facecolor('white')  # 或者: legend.get_frame().set_facecolor('#ffffff')
        legend.get_frame().set_alpha(1.0)          # 确保不透明
        legend.get_frame().set_linewidth(0.5)      # 细边框
        legend.get_frame().set_edgecolor('black')    # 边框颜色
        for text, color in zip(legend.get_texts(), colors1):
            text.set_color(color)
        # 刷新图表
        plt.draw()
        plt.tight_layout()
        plt.savefig('loss_plot_distribution.png')

    def visualize_feature_distributions1(self):
        with torch.no_grad():
            # 转换为numpy数组
            # real_img_embeds = torch.mean(self.real_img_embeds, dim=1).reshape(-1, 1, 224, 224)
            # fake_img_embeds = torch.mean(self.fake_img_embeds, dim=1).reshape(-1, 1, 224, 224)
            feature_vectors = [
                self.img_embeds1,
                self.img_embeds2,
                self.img_embeds3,
                self.img_embeds4,
                self.img_embeds5,
            ]

            # 使用t-SNE降维到2维
            all_features = np.vstack(feature_vectors)
            n_samples = all_features.shape[0]
            perplexity = min(8, 10000)  # 动态调整
            pca = PCA(n_components=2)
            tsne = TSNE(n_components=2, 
                        perplexity=perplexity, 
                        early_exaggeration=12,
                        random_state=42)
            reduced_features = all_features.reshape(n_samples, -1)
            reduced_features = tsne.fit_transform(reduced_features)

        plt.figure(figsize=(6, 5))

        colors = ['#6EC4A9', '#ED949A', '#96CCEA', '#F28E33', '#B2A3DD']  # 扩展颜色列表以匹配元素数量
        labels = ['Fake-Embedding1', 'Fake-Embedding2', 'Fake-Embedding3', 'Fake-Embedding4', 'Fake-Embedding5']

        start_idx = 0
        for i in range(len(feature_vectors)):
            end_idx = start_idx + len(feature_vectors[i])
            plt.scatter(reduced_features[start_idx:end_idx, 0],
                        reduced_features[start_idx:end_idx, 1],
                        c=colors[i],
                        s=7,  # 减小点大小
                        alpha=0.8,  # 增加透明度提升亮度
                        label=labels[i])
            start_idx = end_idx

        plt.title("Feature  Distribution of Four Encoders")
        plt.xlabel('t-SNE  Dimension 1')
        plt.ylabel('t-SNE  Dimension 2')
        # plt.legend(
        #     loc='upper left',
        #     bbox_to_anchor=(1.02, 1),
        #     borderpad=0.3,  # 默认值为0.4，数值越小边框越紧凑
        #     labelspacing=0.3,
        #     handlelength=1.0,
        #     fontsize=6,
        #     frameon=True  # 确保边框显示
        # )
        # 把图例放在图内部右上角，带半透明背景
        legend = plt.legend(
            loc='upper right',
            borderpad=0.2,
            bbox_to_anchor=(1, 1),  # 相对于 axes 的坐标 (1,1) 是右上角，0.98,0.98 稍内缩
            fontsize=7,
            frameon=True
        )
        # 半透明背景（更好融入图中）
        legend.get_frame().set_facecolor('white')  # 或者: legend.get_frame().set_facecolor('#ffffff')
        legend.get_frame().set_alpha(1.0)          # 确保不透明
        legend.get_frame().set_linewidth(0.3)      # 细边框
        # 刷新图表
        plt.draw()
        plt.tight_layout()
        plt.savefig('loss_plot_distribution.png')
    
    

class double_random:
    def __init__(self, real, fake, real_recon, fake_recon):
        import numpy as np
        import matplotlib.pyplot as plt
        from skimage.metrics import mean_squared_error
        self.real = real
        self.fake = fake
        self.real_recon = real_recon
        self.fake_recon = fake_recon

    def calculate_rgb_diff(self, origin, recon):
        """基于RGB三通道计算特征差异"""

        batch_size = origin.shape[0]
        diff_values = []
        with torch.no_grad():
            origin = origin.permute(0, 2, 3, 1).cpu().detach().numpy()  # 形状 (N, H, W, C)
            recon = recon.permute(0, 2, 3, 1).cpu().detach().numpy()
        
        for i in range(batch_size):
            # 提取RGB通道数据（形状h,w,3）
            origin_data = origin[i]
            recon_data = recon[i]
            
            diff = np.mean((origin_data- recon_data)**2)
            diff_values.append(diff)

        return np.array(diff_values)
    
    def double_hist(self):
                # 计算真实与生成图像的特征差异
        real_diff = self.calculate_rgb_diff(origin=self.real, recon=self.real_recon)
        fake_diff = self.calculate_rgb_diff(origin=self.fake, recon=self.fake_recon)

        # ----------------------------
        # 步骤3：绘制双峰直方图
        # ----------------------------
        plt.figure(figsize=(10,6), dpi=120)
        hist_params = {
            "bins": 50,          # 根据网页1的直方图分割建议[1](@ref)
            "alpha": 0.6,       
            "density": False,   
            "range": (np.min([real_diff.min(), fake_diff.min()]),  # 动态范围
                    np.max([real_diff.max(), fake_diff.max()]))  
        }

        plt.hist(real_diff, label='Real Images', color='blue', **hist_params)
        plt.hist(fake_diff, label='Generated Images', color='red', **hist_params)

        # ----------------------------
        # 步骤4：可视化优化
        # ----------------------------
        plt.title("RGB三通道空间差异双峰分布", fontsize=14, pad=15)
        plt.xlabel("RGB向量空间差异值", fontsize=12)
        plt.ylabel("样本数量", fontsize=12)
        plt.legend(loc='upper right')
        plt.grid(axis='y', linestyle='--', alpha=0.3)

        plt.tight_layout()
        plt.savefig('double_recon.png')

    def double_distribution(self):
        import seaborn as sns
        from scipy.stats import gaussian_kde
        real_diff = self.calculate_rgb_diff(origin=self.real, recon=self.real_recon)
        fake_diff = self.calculate_rgb_diff(origin=self.fake, recon=self.fake_recon)
        # ----------------------------
        # 核密度估计（KDE）
        # ----------------------------
        plt.figure(figsize=(10, 6), dpi=120)

        # 绘制真实数据分布
        kde_real = gaussian_kde(real_diff)
        x = np.linspace(min(real_diff.min(), fake_diff.min()),
                        max(real_diff.max(), fake_diff.max()), 1000)
        plt.plot(x, kde_real(x), color='blue', lw=2, label='Real Images')

        # 绘制生成数据分布
        kde_fake = gaussian_kde(fake_diff)
        plt.plot(x, kde_fake(x), color='red', lw=2, label='Generated Images')

        # ----------------------------
        # 可视化优化
        # ----------------------------
        plt.title("RGB三通道差异概率密度分布", fontsize=14, pad=15)
        plt.xlabel("RGB向量空间差异值", fontsize=12)
        plt.ylabel("概率密度", fontsize=12)
        plt.legend()
        plt.grid(linestyle='--', alpha=0.3)

        plt.tight_layout()
        plt.savefig('double_distribution.png')

    def double_normal(self):
        from scipy.stats import norm
        import numpy as np
        import matplotlib.pyplot as plt

        real_diff = self.calculate_rgb_diff(origin=self.real, recon=self.real_recon)
        fake_diff = self.calculate_rgb_diff(origin=self.fake, recon=self.fake_recon)

        # 计算均值和标准差
        mu_real, sigma_real = np.mean(real_diff), np.std(real_diff)
        mu_fake, sigma_fake = np.mean(fake_diff), np.std(fake_diff)
        
        # 固定x轴范围与图片一致
        x = np.linspace(-0.05, 0.05, 500)
        
        # 调整曲线幅度因子
        scaling_factor = 500  # 根据您的图片最高频数约为500调整
        
        # 计算拟合曲线
        y_real = norm.pdf(x, mu_real, sigma_real) * len(real_diff) * (sigma_real * np.sqrt(2*np.pi))
        y_fake = norm.pdf(x, mu_fake, sigma_fake) * len(fake_diff) * (sigma_fake * np.sqrt(2*np.pi))
        
        # 绘图设置
        plt.figure(figsize=(8, 6))
        plt.plot(x, y_real, 'b-', label='Real Normal Fit')
        plt.plot(x, y_fake, 'r-', label='Fake Normal Fit')
        
        plt.title("Distribution_error", fontsize=14)
        plt.ylim(0, 35)
        plt.xlim(-0.05, 0.05)
        plt.xticks(np.arange(-0.05, 0.051, 0.1))
        plt.xlabel("Error_range", fontsize=12)
        plt.ylabel("Frequency", fontsize=12)
        plt.grid(True, alpha=0.3)
        plt.legend(loc='upper right')
        
        plt.tight_layout()
        plt.savefig('visual_picture/double_normal.png', dpi=300)
        plt.close()

    
class Distribution_2:
    def __init__(self, real, fake):
        self.real = real
        self.fake = fake

    def visualize_feature_distributions(self):
        with torch.no_grad():
            # 转换为numpy数组
            # real_img_embeds = torch.mean(self.real_img_embeds, dim=1).reshape(-1, 1, 224, 224)
            # fake_img_embeds = torch.mean(self.fake_img_embeds, dim=1).reshape(-1, 1, 224, 224)
            feature_vectors = [
                self.real,
                self.fake,
            ]

            # 使用t-SNE降维到2维
            all_features = np.vstack(feature_vectors)
            n_samples = all_features.shape[0]
            perplexity = min(8, 10000)  # 动态调整
            pca = PCA(n_components=2)
            tsne = TSNE(n_components=2, 
                        perplexity=perplexity, 
                        early_exaggeration=12,
                        random_state=42)
            reduced_features = all_features.reshape(n_samples, -1)
            reduced_features = tsne.fit_transform(reduced_features)

        plt.figure(figsize=(6, 5))

        colors = ['#6EA8FE', '#ED949A']  # 扩展颜色列表以匹配元素数量
        labels = ['Real-Image', 'Fake-Image']

        start_idx = 0
        for i in range(len(feature_vectors)):
            end_idx = start_idx + len(feature_vectors[i])
            plt.scatter(reduced_features[start_idx:end_idx, 0],
                        reduced_features[start_idx:end_idx, 1],
                        c=colors[i],
                        s=6,  # 减小点大小
                        alpha=0.8,  # 增加透明度提升亮度
                        label=labels[i])
            start_idx = end_idx

        plt.title("Feature  Distribution of Four Encoders")
        plt.xlabel('t-SNE  Dimension 1')
        plt.ylabel('t-SNE  Dimension 2')
        # plt.legend(
        #     loc='upper left',
        #     bbox_to_anchor=(1.02, 1),
        #     borderpad=0.3,  # 默认值为0.4，数值越小边框越紧凑
        #     labelspacing=0.3,
        #     handlelength=1.0,
        #     fontsize=6,
        #     frameon=True  # 确保边框显示
        # )
        # 把图例放在图内部右上角，带半透明背景
        legend = plt.legend(
            loc='upper right',
            borderpad=0.2,
            bbox_to_anchor=(1, 1),  # 相对于 axes 的坐标 (1,1) 是右上角，0.98,0.98 稍内缩
            fontsize=4,
            markerscale=3,
            frameon=True,
            prop={'weight': 'bold'}
        )
        # 半透明背景（更好融入图中）
        # legend.get_frame().set_alpha(0.6)
        legend.get_frame().set_facecolor('white')  # 或者: legend.get_frame().set_facecolor('#ffffff')
        legend.get_frame().set_alpha(1.0)          # 确保不透明
        legend.get_frame().set_linewidth(0.5)      # 细边框
        legend.get_frame().set_edgecolor('black')    # 边框颜色
        # 刷新图表
        plt.draw()
        plt.tight_layout()
        plt.savefig('loss_plot_distribution.png')