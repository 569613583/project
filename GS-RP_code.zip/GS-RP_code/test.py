import torch
import torch.nn as nn
import torch.nn.functional as F
from diffusers import DDPMScheduler, UNet2DConditionModel, AutoencoderKL
from transformers import CLIPVisionModel, CLIPImageProcessor 
from torchvision import transforms
from PIL import Image
import os
import math
from utils import *
from torchvision import models
from torch.autograd import Variable
from DataLoader import celebaDataset
from torch.utils.data import DataLoader
from torchvision.utils import save_image
from grad_clip import AdvDiffusionDetector
from visual1 import Distribution_2
from torch.optim import lr_scheduler
import random

def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)

    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    print(f"Random seed set to {seed}")

# --- 调用 ---
set_seed(42)


def main(dataloader_real, dataloader_fake, classification_logits, opt):

    classification_para = [
    {"params": classification_logits.parameters()},
    ]
    Tensor = torch.cuda.FloatTensor
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    labels_real = torch.zeros(opt.batch_size, 1, device=device)
    labels_fake = torch.ones(opt.batch_size, 1, device=device)
    alternating_labels = torch.cat([labels_real, labels_fake], dim=0)

    Tensor = torch.cuda.FloatTensor
    detector = AdvDiffusionDetector()
    visualizer = ResNet50FocusVisualizer(classification_logits)
    batch_count = 0
    rec_real = []
    rec_fake = []
    all_outputs = []   
    all_targets = []
    real = []
    fake = []

    batches_done = 0
    epoch_acc, epoch_auc, epoch_ap = 0.0, 0.0, 0.0
    for real_imgs, fake_imgs in zip(dataloader_real, dataloader_fake):
        real_imgs = real_imgs.to("cuda")
        fake_imgs = fake_imgs.to("cuda")

        gradient_residual_real, gradient_residual_real_1, grad_orig_real, grad_rec_real, grad_orig_real_1, grad_rec_real_1, orig_img_real, rec_img_real, pixel_error_real, rec_error_real = detector.detect(real_imgs)
        gradient_residual_fake, gradient_residual_fake_1, grad_orig_fake, grad_rec_fake, grad_orig_fake_1, grad_rec_fake_1, orig_img_fake, rec_img_fake, pixel_error_fake, rec_error_fake = detector.detect(fake_imgs)

        # masks = visualizer.get_batch_attention_maps(rec_error_real)
        # final_output = visualizer.overlay_heatmap(rec_error_real.detach().cpu().squeeze().numpy(), masks, alpha=0.5)
        # 1. 获取所有 masks (这是一个 List，长度为 16)
        # masks = visualizer.get_batch_attention_maps(rec_error_real)
        # # 2. 获取原始背景图数组 (B, C, H, W) -> (B, 3, H, W)
        # bg_imgs = rec_error_real.detach().cpu().numpy()
        # final_outputs = []
        # # 3. 逐张进行叠加
        # for i in range(len(masks)):
        #     single_bg = bg_imgs[i]   # 拿到第 i 张图 (3, H, W)
        #     single_mask = masks[i]   # 拿到第 i 个 mask (h, w)
        #     # 得到叠加后的图 (H, W, 3)
        #     res = visualizer.overlay_heatmap(single_bg, single_mask, alpha=0.5)
        #     final_outputs.append(res)
        
        # tensor_list = [
        #                 torch.from_numpy(img[:, :, ::-1].copy()).permute(2, 0, 1).float() / 255.0 
        #                 for img in final_outputs
        #             ]
                    
        # # 将列表合并为一个 4D Tensor: (B, 3, H, W)
        # final_tensor = torch.stack(tensor_list)

        # if batches_done % 5 == 0:
        #         save_image(final_tensor, f"comparison/CAM/CAM_real_{batches_done}.jpg", nrow=4)


        with torch.no_grad():
            # output_real = classification_logits(rec_img_real)
            # output_fake = classification_logits(rec_img_fake)
            # outputs = torch.cat([output_real, output_fake], dim=0)

            inputs_all = torch.cat([rec_error_real, rec_error_fake], dim=0)
            # Ensure dtype consistency between inputs and model weights
            inputs_all = inputs_all.float()
            outputs = classification_logits(inputs_all)
            outputs = torch.sigmoid(outputs)

            all_outputs.append(outputs)
            all_targets.append(alternating_labels)

            batch_acc, batch_auc, batch_ap = compute_metrics(outputs, alternating_labels)
            print(f"ACC: {batch_acc:.4f}, AUC: {batch_auc:.4f}, AP: {batch_ap:.4f}")
            epoch_acc += batch_acc
            epoch_auc += batch_auc
            epoch_ap  += batch_ap
            batches_done += 1
        
        if batches_done % 10 == 0:
            comparison_grid_real = torch.cat([grad_orig_real_1, grad_rec_real_1, gradient_residual_real_1], dim=3)  # 水平拼接真实和生成图像
            comparison_grid_fake = torch.cat([grad_orig_fake_1, grad_rec_fake_1, gradient_residual_fake_1], dim=3)  # 水平拼接真实和生成图像
            comparison_img_real = torch.cat([orig_img_real, rec_img_real, pixel_error_real], dim=3)  
            comparison_img_fake = torch.cat([orig_img_fake, rec_img_fake, pixel_error_fake], dim=3)
            save_image(comparison_grid_real, f"comparison/grad_real/grad_real_{batches_done}.jpg", nrow=4)
            save_image(comparison_grid_fake, f"comparison/grad_fake/grad_fake_{batches_done}.jpg", nrow=4)
            save_image(comparison_img_real, f"comparison/img_real/img_real_{batches_done}.jpg", nrow=4)
            save_image(comparison_img_fake, f"comparison/img_fake/img_fake_{batches_done}.jpg", nrow=4)
            save_image(rec_error_real, f"comparison/error_real/real_{batches_done}.jpg", nrow=4)
            save_image(rec_error_fake, f"comparison/error_fake/fake_{batches_done}.jpg", nrow=4)
        
        if batches_done <= 10:
                real.extend(gradient_residual_real_1.cpu().numpy())
                fake.extend(gradient_residual_fake_1.cpu().numpy())
        if batches_done % 10 == 0 and batches_done <= 10:
            distribution = Distribution_2(
                        real = real,
                        fake = fake, 
                    )
            distribution.visualize_feature_distributions()

    epoch_acc /= batches_done
    epoch_auc /= batches_done
    epoch_ap  /= batches_done
    all_outputs = torch.cat(all_outputs, dim=0) # (total_N,)
    all_targets = torch.cat(all_targets, dim=0) # (total_N,)
    best_thr, best_val, best_ap = find_best_threshold(all_outputs, all_targets, metric='accuracy')
    print(f"基准指标 ACC: {epoch_acc:.4f}, AP: {epoch_ap:.4f}, AUC: {epoch_auc:.4f}")
    print(f"Best_ACC: {best_val:.4f}, Best_AP: {best_ap:.4f}, Best_Thr: {best_thr:.9f}")



if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--n_epochs", type=int, default=50, help="number of epochs of training")
    parser.add_argument("--b1", type=float, default=0.9, help="adam: decay of first order momentum of gradient")
    parser.add_argument("--b2", type=float, default=0.999, help="adam: decay of first order momentum of gradient")
    parser.add_argument("--channels", type=int, default=3, help="number of image channels")
    parser.add_argument("--batch_size", type=int, default=16, help="batch size")
    opt = parser.parse_args()


    # img_pth_real = "./dataset/DIRE/test/lsun_bedroom/real"   
    # dataset_real = celebaDataset(img_pth_real, size=224)
    # dataloader_real = DataLoader(dataset_real, batch_size=opt.batch_size, shuffle=True, num_workers=4, drop_last=True)
    # img_pth_fake = "./dataset/DIRE/test/lsun_bedroom/sdv2"    
    # dataset_fake = celebaDataset(img_pth_fake, size=224)
    # dataloader_fake = DataLoader(dataset_fake, batch_size=opt.batch_size, shuffle=True, num_workers=4, drop_last=True)

    img_pth_real = "./dataset/DIRE/test/celebahq/real"   
    dataset_real = celebaDataset(img_pth_real, size=224)
    dataloader_real = DataLoader(dataset_real, batch_size=opt.batch_size, shuffle=True, num_workers=4, drop_last=True)
    img_pth_fake = "./dataset/DIRE/test/celebahq/sdv2"    
    dataset_fake = celebaDataset(img_pth_fake, size=224)
    dataloader_fake = DataLoader(dataset_fake, batch_size=opt.batch_size, shuffle=True, num_workers=4, drop_last=True)

    classification_logits = models.resnet50(pretrained=False)
    old_conv = classification_logits.conv1
    classification_logits.conv1 = nn.Conv2d(
        in_channels=3,
        out_channels=old_conv.out_channels,  
        kernel_size=old_conv.kernel_size,    
        stride=old_conv.stride,              
        padding=old_conv.padding,            
        bias=old_conv.bias is not None
    )
    num_ftrs = classification_logits.fc.in_features
    classification_logits.fc = nn.Linear(num_ftrs, 1)
    classification_logits.load_state_dict(torch.load("weights"))
    classification_logits.eval()
    classification_logits.cuda()

    main(dataloader_real, dataloader_fake, classification_logits, opt)

        