import torch
import torch.nn as nn
import torch.nn.functional as F
from diffusers import DDPMScheduler, UNet2DConditionModel, AutoencoderKL
from transformers import CLIPVisionModel, CLIPImageProcessor 
from torchvision import transforms
from PIL import Image
import os
import math
import lpips
import clip
import random
import numpy as np

# def set_seed(seed=42):
#     random.seed(seed)
#     np.random.seed(seed)

#     torch.manual_seed(seed)
#     torch.cuda.manual_seed(seed)
#     torch.cuda.manual_seed_all(seed)

#     print(f"Random seed set to {seed}")

# # --- 调用 ---
# set_seed(42)

MODEL_ID = "coder/SD-1.4"
VIT_MODEL_ID = "coder/clip/RN50.pt" 
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

class AdvDiffusionDetector:
    def __init__(self):
        self.device = DEVICE
        # --- 1. 加载 SD v1.4 组件 ---
        print(f"Loading Diffusion components from {MODEL_ID}...")
        self.unet = UNet2DConditionModel.from_pretrained(
            MODEL_ID, subfolder="unet"
        ).to(self.device)
        self.vae = AutoencoderKL.from_pretrained(
            MODEL_ID, subfolder="vae"
        ).to(self.device)
        self.scheduler = DDPMScheduler.from_pretrained(MODEL_ID, subfolder="scheduler")
        
        # 冻结 SD 组件
        self.unet.requires_grad_(False); self.vae.requires_grad_(False)
        self.unet.eval(); self.vae.eval()

        # --- 2. 加载 ViT-L/14 用于提取梯度 ---
        print(f"Loading ViT-L/14 feature extractor from {VIT_MODEL_ID}...")
        # 注意: jit=False 允许我们动态追踪梯度
        self.clip_model, _ = clip.load(VIT_MODEL_ID, device=self.device, jit=False)
        self.clip_model.requires_grad_(False); self.clip_model.eval()

        # 定义 CLIP 期望的维度 (SequenceLength=77, EmbedDim=768) 用于 Unet 条件
        self.CLIP_SEQ_LEN = 77
        self.CLIP_EMBED_DIM = 768

        self.error_method = 'cosine'

        # 定义 CLIP 的归一化参数 (用于将 [0,1] 图像转为 CLIP 输入)
        self.clip_mean = torch.tensor([0.48145466, 0.4578275, 0.40821073]).view(1, 3, 1, 1).to(self.device)
        self.clip_std = torch.tensor([0.26862954, 0.26130258, 0.27577711]).view(1, 3, 1, 1).to(self.device)

    def preprocess_for_clip(self, img_tensor):
        """
        将范围 [-1, 1] 的图像转换为 CLIP 需要的归一化格式
        """
        if img_tensor.min() < 0:
            img_norm = (img_tensor / 2 + 0.5)
        return img_norm

    @torch.no_grad()
    def purify(self, adv_img_tensor: torch.Tensor, num_inference_steps=20, strength=0.95):
        """
        DDIM 逆向采样，adv_img_tensor 是批次输入 (B, C, H, W)。
        """
        adv_latents = self.vae.encode(adv_img_tensor).latent_dist.mode() * self.vae.config.scaling_factor
        B = adv_img_tensor.shape[0]
        
        self.scheduler.set_timesteps(num_inference_steps, device=self.device)
        t_start = int(num_inference_steps * (1 - strength))
        timesteps = self.scheduler.timesteps[-t_start:]

        uncond_embedding = torch.zeros(
            (B, self.CLIP_SEQ_LEN, self.CLIP_EMBED_DIM), 
            dtype=adv_img_tensor.dtype,
            device=self.device
        )
        # -----------------------------------------------

        if t_start > 0:
            initial_timestep = timesteps[0]
            noise = torch.randn_like(adv_latents)
            latents = self.scheduler.add_noise(adv_latents, noise, initial_timestep)
        else:
            latents = adv_latents

        for t in timesteps:
            # --- 错误修复点 4: U-Net 调用时传入零张量 ---
            model_output = self.unet(
                latents, 
                t, 
                encoder_hidden_states=uncond_embedding
            ).sample
            # -----------------------------------------------
            latents = self.scheduler.step(model_output, t, latents).prev_sample

        rec_img_tensor = self.vae.decode(latents / self.vae.config.scaling_factor).sample
        # rec_img_tensor = (rec_img_tensor / 2 + 0.5).clamp(0, 1)
        
        return rec_img_tensor

    def mask_fusion(self, pixel_error, grad_error, T=0.5):
        B, _, H, W = pixel_error.shape

        mask = torch.norm(grad_error, dim=1, keepdim=True)

        mask = mask.view(B, -1)
        mask = (mask - mask.min(dim=1, keepdim=True)[0]) / \
            (mask.max(dim=1, keepdim=True)[0] - mask.min(dim=1, keepdim=True)[0] + 1e-8)
        mask = mask.view(B, 1, H, W)

        mask = torch.sigmoid(mask / T)
        fused = pixel_error * (1 + mask)
        return fused

    # --- ViT 特征提取与检测 ---
    def get_input_gradient(self, img_tensor: torch.Tensor):
        """
        关键步骤：计算 LGrad (图像梯度)
        输入: img_tensor (B, C, H, W) 范围建议为 [-1, 1]
        输出: gradient_map (B, C, H, W)
        """
        # 1. 预处理：将 SD 格式 [-1, 1] 转为 CLIP 格式并 Detach，防止梯度传回 VAE
        # 使用 detach() 切断与之前 SD 重建过程的梯度联系
        img_input = self.preprocess_for_clip(img_tensor.detach())
        
        # 2. 关键：开启输入图像的梯度追踪
        img_input.requires_grad_(True)
        img_input.retain_grad()

        # 3. 清空模型梯度
        self.clip_model.zero_grad()
        # self.vae.zero_grad()
        
        # 4. 前向传播：获取特征
        features = self.clip_model.encode_image(img_input)
        # features = self.vae.encode(img_input).latent_dist.mean
        
        # 5. LGrad 核心：构造标量 Loss (Sum of features)
        # 这代表了模型对图像内容的整体激活程度
        loss = features.sum()
        
        # 6. 反向传播：求对输入 img_input 的导数
        loss.backward()
        
        # 7. 获取梯度并取绝对值 (关注敏感度大小，忽略方向)
        # 结果 shape: [B, 3, H, W]
        grad = img_input.grad.abs()
        
        # 8. (可选) 简单的归一化，防止梯度数值过小
        # 这里不做复杂归一化，保留相对大小，交给分类器处理
        return grad
      

    def visualize_lgrad(self, grad_tensor):
        """
        将原始梯度 [B, 3, H, W] 转换为 LGrad 论文风格的效果
        """
        # --- Step 1: 能量聚合 ---
        # 论文中通常关注的是梯度的强度。在通道维度取 L2 范数，将 RGB 变单通道能量图
        # grad_energy = torch.norm(grad_tensor, dim=1, keepdim=True)
        grad_energy = grad_tensor

        # --- Step 2: 对数变换 (非常关键) ---
        # 梯度的值分布极度不均，大部分很小，极少数很大。
        # 对数变换能压制极值，拉高低频细节，让伪影显现出来。
        grad_energy = torch.log(grad_energy + 1e-7)

        # # --- Step 3: 归一化到 [0, 1] ---
        b, c, h, w = grad_energy.shape
        grad_view = grad_energy.view(b, -1)
        v_min = grad_view.min(dim=1, keepdim=True)[0]
        v_max = grad_view.max(dim=1, keepdim=True)[0]
        grad_norm = (grad_view - v_min) / (v_max - v_min + 1e-8)
        grad_norm = grad_norm.view(b, c, h, w)

        # --- Step 4: 高斯平滑 (去除碎点噪声) ---
        # 论文图看起来丝滑是因为滤掉了像素级杂讯，保留了区域性的“伪影块”
        # import torchvision.transforms.functional as TF
        # # 建议使用 5x5 或 7x7 的核，sigma 在 1.0~2.0 之间
        # grad_norm = TF.gaussian_blur(grad_energy, kernel_size=[5, 5], sigma=[1.5, 1.5])

        return grad_norm

    
    def get_error_map(self, g_orig, g_rec):
        """
        计算空间误差图 [B, C, H, W]，用于输入 ResNet
        """
        if self.error_method == 'residual':
            # 方法1: 直接相减 (保留正负)
            err_map = g_orig - g_rec
            
        elif self.error_method == 'abs':
            # 方法2: 绝对差异 (关注幅度)
            err_map = torch.abs(g_orig - g_rec)
            
        elif self.error_method == 'cosine':
            # 方法3: 逐像素余弦距离 (关注方向)
            # 这是一个比较高级的特征
            g_orig_norm = F.normalize(g_orig, dim=1)
            g_rec_norm = F.normalize(g_rec, dim=1)
            # 1 - cos_sim，范围 [0, 2]
            err_map = 1 - (g_orig * g_rec) 
        
        else:
            raise ValueError("Unknown method")
            
        return err_map

    def detect(self, img_tensor: torch.Tensor):
        """
        全流程：重建 -> 梯度计算 -> 误差计算
        输入: img_tensor (B, C, H, W), 假设范围 [-1, 1] (如果是 [0,1] 请先转换)
        返回: 梯度残差图 (gradient_residual)
        """
        img_tensor = img_tensor.to(self.device)
        
        # --- Step 1: SD 重建 ---
        # 重建后的图像 rec_img 也在 [-1, 1] 范围
        rec_img = self.purify(img_tensor) 

        # --- Step 2: 提取 原始图像 的梯度 ---
        grad_orig = self.get_input_gradient(img_tensor)
        grad_orig_1 = self.visualize_lgrad(grad_orig)
        
        # --- Step 3: 提取 重建图像 的梯度 ---
        grad_rec = self.get_input_gradient(rec_img)
        grad_rec_1 = self.visualize_lgrad(grad_rec)
        
        img_tensor = self.preprocess_for_clip(img_tensor)
        rec_img = self.preprocess_for_clip(rec_img)

        # --- Step 4: 计算梯度残差 (Residual) ---
        # 逻辑：真图的重建梯度应与原图相似(残差小)，假图重建后伪影消失(残差大)
        gradient_residual = self.get_error_map(grad_orig, grad_rec)
        gradient_residual_1 = self.get_error_map(grad_orig_1, grad_rec_1)
        # gradient_residual_1 = gradient_residual_1 * img_tensor

        rec_error = img_tensor - rec_img
        # rec_grad_error = 1 - F.cosine_similarity(grad_orig, grad_rec, dim=1)
        result = self.mask_fusion(rec_error, gradient_residual)

        # print(gradient_residual_1.mean().item())
        
        # 返回残差图，供后续 ResNet 分类器使用
        # 同时也返回 rec_img 和 grad_orig 方便可视化调试
        return gradient_residual, gradient_residual_1, grad_orig, grad_rec, grad_orig_1, grad_rec_1, img_tensor, rec_img, rec_error, result