import torch
import torch.nn as nn
import torch.nn.functional as F
from diffusers import DDPMScheduler, UNet2DConditionModel, AutoencoderKL
from transformers import CLIPVisionModel, CLIPImageProcessor 
from torchvision import transforms
from PIL import Image
import os
import math
from utils import *
from torchvision import models
from torch.autograd import Variable
from DataLoader import celebaDataset
from torch.utils.data import DataLoader
from torchvision.utils import save_image
from grad_clip import AdvDiffusionDetector
from visual1 import Distribution_2
from torch.optim import lr_scheduler


def main(dataloader_real, dataloader_fake, classification_logits, opt):

    classification_para = [
    {"params": classification_logits.parameters()},
    ]
    Tensor = torch.cuda.FloatTensor
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.Adam(classification_para, lr=9e-5, betas=(opt.b1, opt.b2)) 
    scheduler = lr_scheduler.CosineAnnealingWarmRestarts(
        optimizer,  
        T_0=50,       
        T_mult=1,     
        eta_min=0.000000000001     
    )

    labels_real = torch.zeros(opt.batch_size, 1, device=device)
    labels_fake = torch.ones(opt.batch_size, 1, device=device)
    alternating_labels = torch.cat([labels_real, labels_fake], dim=0)

    Tensor = torch.cuda.FloatTensor
    detector = AdvDiffusionDetector()
    batch_count = 0
    real = []
    fake = []

    for epoch in range(opt.n_epochs+1):
        epoch_acc, epoch_auc, epoch_ap = 0.0, 0.0, 0.0
        batches_done = 0
        classification_logits.train()
        for real_imgs, fake_imgs in zip(dataloader_real, dataloader_fake):
            real_imgs = real_imgs.to("cuda")
            fake_imgs = fake_imgs.to("cuda")

            gradient_residual_real, gradient_residual_real_1, grad_orig_real, grad_rec_real, grad_orig_real_1, grad_rec_real_1, orig_img_real, rec_img_real, pixel_error_real, rec_error_real = detector.detect(real_imgs)
            gradient_residual_fake, gradient_residual_fake_1, grad_orig_fake, grad_rec_fake, grad_orig_fake_1, grad_rec_fake_1, orig_img_fake, rec_img_fake, pixel_error_fake, rec_error_fake = detector.detect(fake_imgs)

            # print(f"Real: {mse_score_real}")
            # print(f"Fake: {mse_score_fake}")

            optimizer.zero_grad()
            inputs_all = torch.cat([pixel_error_real, pixel_error_fake], dim=0)
            # inputs_all = torch.cat([rec_error_real, rec_error_fake], dim=0)
            inputs_all = inputs_all.float()
            outputs = classification_logits(inputs_all)
            loss = criterion(outputs, alternating_labels)
            loss.backward()
            optimizer.step()

            batch_acc, batch_auc, batch_ap = compute_metrics(outputs, alternating_labels)
            epoch_acc += batch_acc
            epoch_auc += batch_auc
            epoch_ap  += batch_ap
            print("[Epoch %d/%d] [lr scheduler: %.10f] [loss: %.10f]" % (epoch, opt.n_epochs, get_lr(optimizer), loss.item()))
            batches_done += 1

            if batches_done % 1000 == 0:
                comparison_grid_real = torch.cat([grad_orig_real_1, grad_rec_real_1, gradient_residual_real_1], dim=3)  # 水平拼接真实和生成图像
                comparison_grid_fake = torch.cat([grad_orig_fake_1, grad_rec_fake_1, gradient_residual_fake_1], dim=3)  # 水平拼接真实和生成图像
                comparison_img_real = torch.cat([orig_img_real, rec_img_real, orig_img_real-rec_img_real], dim=3)  
                comparison_img_fake = torch.cat([orig_img_fake, rec_img_fake, orig_img_fake-rec_img_fake], dim=3)
                save_image(comparison_grid_real, f"comparison/grad_real/grad_real_{batches_done}.jpg", nrow=4)
                save_image(comparison_grid_fake, f"comparison/grad_fake/grad_fake_{batches_done}.jpg", nrow=4)
                save_image(comparison_img_real, f"comparison/img_real/img_real_{batches_done}.jpg", nrow=4)
                save_image(comparison_img_fake, f"comparison/img_fake/img_fake_{batches_done}.jpg", nrow=4)
                save_image(rec_error_real, f"comparison/error_real/real_{batches_done}.jpg", nrow=4)
                save_image(rec_error_fake, f"comparison/error_fake/fake_{batches_done}.jpg", nrow=4)
        

       
            # if batches_done <= 20:
            #     real.extend(rec_error_real.cpu().numpy())
            #     fake.extend(rec_error_fake.cpu().numpy())
            # if batches_done % 20 == 0 and batches_done <= 20:
            #     distribution = Distribution_2(
            #                 real = real,
            #                 fake = fake, 
            #             )
            #     distribution.visualize_feature_distributions()
            
        scheduler.step()
        epoch_acc /= batches_done
        epoch_auc /= batches_done
        epoch_ap  /= batches_done
        print(f"[Epoch {epoch}] ACC: {epoch_acc:.4f}, AUC: {epoch_auc:.4f}, AP: {epoch_ap:.4f}")
        batch_count += 1

        if epoch % 1 == 0:
            torch.save(classification_logits.state_dict(), f"weights/baseline/dire/classification_{epoch}.pth")

        



if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--n_epochs", type=int, default=100, help="number of epochs of training")
    parser.add_argument("--b1", type=float, default=0.9, help="adam: decay of first order momentum of gradient")
    parser.add_argument("--b2", type=float, default=0.999, help="adam: decay of first order momentum of gradient")
    parser.add_argument("--channels", type=int, default=3, help="number of image channels")
    parser.add_argument("--batch_size", type=int, default=16, help="batch size")
    opt = parser.parse_args()


    img_pth_real = "./dataset/DIRE/train/real"   
    dataset_real = celebaDataset(img_pth_real, size=224)
    dataloader_real = DataLoader(dataset_real, batch_size=opt.batch_size, shuffle=True, num_workers=4, drop_last=True)
    img_pth_fake = "./dataset/DIRE/train/adm"    
    dataset_fake = celebaDataset(img_pth_fake, size=224)
    dataloader_fake = DataLoader(dataset_fake, batch_size=opt.batch_size, shuffle=True, num_workers=4, drop_last=True)

    # img_pth_real = "./dataset/face_DIRE/real"   
    # dataset_real = celebaDataset(img_pth_real, size=224)
    # dataloader_real = DataLoader(dataset_real, batch_size=opt.batch_size, shuffle=True, num_workers=4, drop_last=True)
    # img_pth_fake = "./dataset/face_DIRE/sdv2"    
    # dataset_fake = celebaDataset(img_pth_fake, size=224)
    # dataloader_fake = DataLoader(dataset_fake, batch_size=opt.batch_size, shuffle=True, num_workers=4, drop_last=True)

    classification_logits = models.resnet50(pretrained=False)
    old_conv = classification_logits.conv1
    classification_logits.conv1 = nn.Conv2d(
        in_channels=3,
        out_channels=old_conv.out_channels,  
        kernel_size=old_conv.kernel_size,    
        stride=old_conv.stride,              
        padding=old_conv.padding,            
        bias=old_conv.bias is not None
    )
    num_ftrs = classification_logits.fc.in_features
    classification_logits.fc = nn.Linear(num_ftrs, 1)
    classification_logits.cuda()

    main(dataloader_real, dataloader_fake, classification_logits, opt)

