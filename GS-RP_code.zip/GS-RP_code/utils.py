import torch
import torch.nn as nn
from enum import Enum
import cv2
import torch.nn.functional as F

try:
    from sklearn.metrics import roc_auc_score
    _HAS_SKLEARN = True
except Exception:
    _HAS_SKLEARN = False
from torchmetrics import Accuracy, AUROC, AveragePrecision
import numpy as np

def compute_metrics(outputs_logits, targets):
    """
    outputs_logits: tensor [N,1] or [N]
    targets: tensor [N,1] or [N] (0/1)
    返回 (acc_float, auc_float)
    """
    with torch.no_grad():
        ap_metric = AveragePrecision(task='binary')
        probs = outputs_logits.view(-1).cpu()
        targets = targets.view(-1).cpu().long()
        preds = (probs > 0.5).long()
        acc = (preds == targets).float().mean().item()
        ap = float(ap_metric(probs, targets.long()))
        # AUC
        try:
            if _HAS_SKLEARN:
                auc = float(roc_auc_score(targets.numpy(), probs.numpy()))
            else:
                auc_metric = AUROC(task='binary')
                auc = float(auc_metric(probs, targets))
                ap = float(ap_metric(probs, targets))
        except Exception:
            auc = 0.5
    return acc, auc, ap

def freeze_model(model: torch.nn.Module):
    for name, params in model.named_parameters():
        params.requires_grad = False  # 停止梯度计算
    return model

def freeze_model_stable(model: torch.nn.Module):
    for component in [
        model.unet,
        model.vae,
        model.text_encoder,
        model.safety_checker
        ]:
        for param in component.parameters():
            param.requires_grad = False
    return model

def reinit_weights(m):
    # Conv2d
    if isinstance(m, nn.Conv2d):
        nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
        if m.bias is not None:
            nn.init.zeros_(m.bias)
    # Linear
    elif isinstance(m, nn.Linear):
        nn.init.xavier_uniform_(m.weight)
        if m.bias is not None:
            nn.init.zeros_(m.bias)
    # LayerNorm / BatchNorm
    elif isinstance(m, (nn.LayerNorm, nn.BatchNorm1d, nn.BatchNorm2d)):
        if hasattr(m, 'weight') and m.weight is not None:
            nn.init.ones_(m.weight)
        if hasattr(m, 'bias') and m.bias is not None:
            nn.init.zeros_(m.bias)
    # Embedding
    elif isinstance(m, nn.Embedding):
        nn.init.normal_(m.weight, std=0.02)

def activate_model(model: torch.nn.Module):
    for name, params in model.named_parameters():
        params.requires_grad = True  # 恢复梯度计算
    return model

def accuracy(output, target, topk=(1,)):
    """Computes the accuracy over the k top predictions for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        _, pred = output.topk(maxk, 1, True, True)  # 取前k个最大值和索引
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred))

        results = []
        for k in topk:
            correct_k = correct[:k].reshape(-1).float().sum(0, keepdim=True)
            results.append(correct_k.mul_(100.0 / batch_size))
        return results

def get_lr(optimizer):
    # 获取当前学习率
    lrs = []
    for param_group in optimizer.param_groups:
        lr = float(param_group['lr'])
        lrs.append(lr)

    return max(lrs)

class Summary(Enum):
    NONE = 0
    AVERAGE = 1
    SUM = 2
    COUNT = 3

class AverageMeter(object):
    def __init__(self, name, fmt=":f", summary_type=Summary.AVERAGE):
        self.name = name
        self.fmt = fmt
        self.summary_type = summary_type
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

    def __str__(self):
        fmtstr = "{name} {val" + self.fmt + "} ({avg" + self.fmt + "})"
        return fmtstr.format(**self.__dict__)

    def summary(self):
        if self.summary_type is Summary.NONE:
            fmtstr = ""
        elif self.summary_type is Summary.AVERAGE:
            fmtstr = "{name} {avg:.2f}"
        elif self.summary_type is Summary.SUM:
            fmtstr = "{name} {sum:.2f}"
        elif self.summary_type is Summary.COUNT:
            fmtstr = "{name} {count:.2f}"
        else:
            raise ValueError(f"Invalid summary type {self.summary_type}")

        return fmtstr.format(**self.__dict__)

def find_best_threshold(outputs_logits, targets, metric='accuracy'):
    with torch.no_grad():
        ap_metric = AveragePrecision(task='binary')
        probs = outputs_logits.view(-1).cpu()
        targets = targets.view(-1).cpu()
        thresholds = np.linspace(0.0001, 0.999, 999)
        best_thr, best_val = 0.5, 0.0
        for t in thresholds:
            preds = (probs > t)
            val = Accuracy(task='binary')(preds, targets)  # or f1_score(...)
            if val > best_val:
                best_val = val
                best_thr = t
                best_ap = float(ap_metric(probs, targets.long()))
    return best_thr, best_val, best_ap


class ResNet50FocusVisualizer:
    def __init__(self, model):
        self.model = model
        self.model.eval()
        self.features = None
        self.gradients = None
        self.hooks = []
        
        # 对于标准的 ResNet50，最后一个卷积层是 layer4 的最后一个 bottleneck 的 conv3 或其输出
        self.target_layer = self.model.layer4[-1]
        self._register_hooks()

    def _register_hooks(self):
        def forward_hook(module, input, output):
            self.features = output
        def backward_hook(module, grad_input, grad_output):
            self.gradients = grad_output[0]

        self.hooks.append(self.target_layer.register_forward_hook(forward_hook))
        self.hooks.append(self.target_layer.register_full_backward_hook(backward_hook))

    def get_batch_attention_maps(self, error_map_batch, target_classes=None):
        """
        error_map_batch: 形状为 (B, 3, H, W) 的张量 (例如 16张图)
        target_classes: 长度为 B 的列表，指定每张图的目标类。若为 None 则自动取预测类。
        """
        self.model.eval()
        B, C, H, W = error_map_batch.shape
        all_masks = []

        # 逐张图像处理，确保梯度计算准确且不会内存溢出
        for i in range(B):
            single_input = error_map_batch[i:i+1] # 保持 (1, 3, H, W) 维度
            self.model.zero_grad()
            output = self.model(single_input)
            
            if target_classes is None:
                target_cls = output.argmax(dim=1).item()
            else:
                target_cls = target_classes[i]

            # 反向传播
            loss = output[0, target_cls]
            loss.backward()

            # 计算当前图像的 Grad-CAM
            weights = torch.mean(self.gradients, dim=(2, 3), keepdim=True)
            cam = torch.sum(weights * self.features, dim=1, keepdim=True)
            cam = F.relu(cam)
            
            # 归一化处理
            cam_np = cam.detach().cpu().squeeze().numpy()
            cam_np = 1 - (cam_np - cam_np.min()) / (cam_np.max() - cam_np.min() + 1e-8)
            
            all_masks.append(cam_np)
            
        return all_masks # 返回 16 个 mask 的列表

    @staticmethod
    def overlay_heatmap(background_img, attention_map, alpha=0.5):
        """
        background_img: 原始彩色图或误差图 (numpy BGR)
        attention_map: get_attention_map 生成的 0-1 矩阵
        """
        # 缩放并平滑，得到类似左图的圆润热点区域
        mask = cv2.resize(attention_map, (background_img.shape[1], background_img.shape[0]))
        mask = cv2.GaussianBlur(mask, (21, 21), 0) # 高斯模糊让热图更自然
        mask = np.uint8(255 * mask)
        
        # 伪彩色映射
        heatmap = cv2.applyColorMap(mask, cv2.COLORMAP_JET)
        
        # 叠加显示
        result = cv2.addWeighted(background_img, 1 - alpha, heatmap, alpha, 0)
        return result