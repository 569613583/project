# Universal AIGC Detection via Gradient Sensitivity-Guided Reconstruction Preference

GS-RP 使用 Stable Diffusion v1.4 重建图像，比较原图与重建图的 CLIP-RN50 输入梯度，并用梯度变化对像素级重建误差加权。论文在 DiffusionForensics 的卧室和人脸子集上评估跨生成器检测表现。

| 路径 | 内容 |
| --- | --- |
| [paper.pdf](paper.pdf) | AT4 最终论文 |
| [src/](src/) | 原始训练、评估、特征提取与可视化代码 |
| [requirements.txt](requirements.txt) | 源码直接使用的 Python 依赖 |
| [results/](results/) | 论文中的定量结果表及随源码提供的可视化 |

## 安装环境

训练和评估脚本直接调用 CUDA。请在配有 NVIDIA GPU 的机器上使用独立的 Python 环境，并根据驱动选择匹配的 PyTorch 和 torchvision 构建。依赖表按源码导入项整理，未锁定论文实验环境的版本。

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

CLIP 依赖使用 [OpenAI CLIP](https://github.com/openai/CLIP) 的 Git 仓库，安装时需要 Git。

## 准备数据和权重

从 [DIRE 官方仓库](https://github.com/ZhendongWang6/DIRE) 获取 DiffusionForensics。将原始 RGB 图像按用途映射到脚本中使用的目录。下面列出启用中的默认路径。

```text
dataset/DIRE/train/real/           # 卧室训练真实图
dataset/DIRE/train/adm/            # 卧室训练 ADM 图
dataset/DIRE/test/celebahq/real/    # 人脸测试真实图
dataset/DIRE/test/celebahq/sdv2/    # 人脸测试 SD-v2 图
coder/SD-1.4/unet/
coder/SD-1.4/vae/
coder/SD-1.4/scheduler/
coder/clip/RN50.pt
```

Stable Diffusion 权重和配置来自 [CompVis Stable Diffusion v1.4](https://huggingface.co/CompVis/stable-diffusion-v1-4)。复制对应的 Diffusers 子目录。原始代码中 RN50 权重路径使用小写的 `clip`。可运行下列命令，将 OpenAI CLIP 的 RN50 权重下载到该目录。

```bash
python -c 'import clip; clip.load("RN50", device="cpu", download_root="coder/clip")'
```

完整数据集、预训练模型和论文对应的 GS-RP 分类器权重需要另行准备。原始压缩包中的相应目录为空。

## 运行现有脚本

安装依赖并准备数据后，在仓库根目录运行。默认训练入口对应卧室数据，保存路径来自原始脚本。

```bash
mkdir -p weights/baseline/dire
mkdir -p comparison/grad_real comparison/grad_fake comparison/img_real \
  comparison/img_fake comparison/error_real comparison/error_fake
python src/train.py --batch_size 16
```

默认评估入口读取 CelebA-HQ 真实脸图和 SD-v2 脸图，要求工作目录中的 `weights` 是一个检查点文件。训练入口则使用同名目录。可以在独立工作目录中运行评估，通过软链接提供数据和权重，保持源文件原样。

```bash
repo_root="$(pwd)"
checkpoint="/absolute/path/to/your-face-gs-rp-checkpoint.pth"
test -f "$checkpoint" && test -d "$repo_root/coder" && test -d "$repo_root/dataset" || exit 1
eval_dir="$(mktemp -d)"
ln -s "$repo_root/dataset" "$eval_dir/dataset"
ln -s "$repo_root/coder" "$eval_dir/coder"
ln -s "$checkpoint" "$eval_dir/weights"
(
  cd "$eval_dir"
  mkdir -p comparison/grad_real comparison/grad_fake comparison/img_real \
    comparison/img_fake comparison/error_real comparison/error_fake
  python "$repo_root/src/test.py" --batch_size 16
)
```

评估其他生成器或训练人脸模型时，需要选择相应的数据路径和匹配的分类器权重。论文的数据划分和指标口径见 `paper.pdf` 的 Experiments。原始脚本包含以下与复现有关的差异。

- `train.py` 默认用像素残差训练，保留了融合特征训练分支的注释。 `test.py` 默认用融合特征评估。论文 GS-RP 结果对应融合特征，评估时需使用在相同特征上训练的检查点。
- `train.py` 默认批大小为每类 16，真假样本合并后每步共 32 张。该脚本硬编码的初始学习率为 `9e-5`，论文报告为 `1e-4`。
- 测试会丢弃不足整批的数据，并按较短类别结束配对迭代。脚本同时输出固定 0.5 阈值下的准确率和在当前测试数据上搜索的阈值结果。论文使用固定 0.5 阈值。原始脚本的批级 AP 均值与对整个测试集一次计算的 AP 具有不同口径。

## 实验结果

### 论文图示

| 论文图号 | 图示 |
| --- | --- |
| 图 1 | [GS-RP 方法总览](results/method_overview.png) |
| 图 2 | [真假图像的像素残差、梯度差异与融合图](results/artifact.png) |
| 图 3 | [人脸特征的 t-SNE 可视化](results/face_tsne.png) |

### 定量结果

[卧室结果 CSV](results/bedroom.csv) 对应论文表 1，[人脸结果 CSV](results/face.csv) 对应论文表 2。CSV 记录各方法在每个生成器上的 ACC 与 AP，单位为百分比。`Mean` 行按原表录入。结果来自随附论文，整理仓库时未重新运行实验。
